# Trabalho de Programação 
# Sobre 
Este é um site para voce que está procurando vestidos 
## Recursos de Acesibilidade 
-Atributo aria
-alt
-tab-index
-menu de acesibilidade
## Tecnologia utilizada
-HTML
-CSS
-JS